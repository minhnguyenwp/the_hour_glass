exports.index = function(req, res) {
  res.render('index');
};

exports.contact = function(req, res) {
  res.render('contact');
};

exports.cate = function(req, res) {
  res.render('cate');
};